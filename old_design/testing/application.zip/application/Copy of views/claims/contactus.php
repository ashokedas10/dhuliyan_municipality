
<div>
<table border="0" cellpadding="0" width="417">
  <tr>
    <td valign="top"><p>Indrani Bharat Nirman  Parivar Limited<br />
</p></td>
  </tr>
  <tr>
    <td width="409" valign="top"><br />
      <strong>Regd. &amp; Head    Office:&nbsp;</strong><br />
      <br />
      32A, Girish Chandra Bose Road, Kolkata-700 014 </td>
  </tr>
  <tr>
    <td valign="top"><p><strong>Corporate  Office:</strong>&nbsp;<br />
    <br />
  34, Girish Chandra Bose Road, Kolkata &ndash; 700014<br />
  <strong>Landline:</strong>&nbsp;033 2226 8463<br />
  <strong>Mobile:</strong><strong>&nbsp;</strong>+91 90380 09504<br />
  <strong>E-mail:</strong>&nbsp;<a href="mailto:shamindradas@pocketbazar.net">enquiry@pocketbazar.net</a> </p></td>
  </tr>
</table>
</div>

