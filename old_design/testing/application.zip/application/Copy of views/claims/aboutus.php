
<div class="main">
	<div class="head_one">
				<div class="about_us">
					<b><u>About Us</b></u>
					<p>It's nice of you to take the time to get to know us better. Here are some things about us that we thought 
					you might like to know.<br />
					<br />Pocketbazar went live in 2013 with the objective of online selling and/or providing services related to 
					Electronics Products, Train, Flight, Hotel & Cruise Line Booking, etc., Medical Services such as Ambulance, 
					Pathology, Medicine, Consultancy such as Hotel , Restaurant, FMCG Retail Chain, Media & Market 
					Promotion, FMCG Products, Garments & Jewellery, IT Solution such as Website, Hardware, Software etc. 
					easily available to anyone who had internet access. Today, we're present across various categories 
					including movies, music, games, mobiles, cameras, computers, healthcare and personal products, home 
					appliances and stationery, perfumes, toys, apparels, shoes, Placement&minus;National & International, Real 
					Estate such as Land, Property & Car Marketing, Mobile Recharge & All Bill Payment, Event Management, 
					Package Tour & Catering and still counting!<br />
					<br />Be it our path-breaking services like Cash on Delivery, a 30-day replacement policy, EMI options, free 
					shipping - and of course the great prices that we offer, everything we do revolves around our obsession 
					with providing our customers a memorable online shopping experience. Then there's our dedicated 
					Pocketbazar delivery partners who work round the clock to personally make sure the packages reach on 
					time.<br />
					<br />So it's no surprise that we're a favorite online shopping destination.</p>
				</div>
	</div>
</div>