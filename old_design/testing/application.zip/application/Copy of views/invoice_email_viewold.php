<?php 

$userid='Ashoke Das';	
$pwd='123654';
$refuid='Indrani';
echo $emailmsg='<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CardsThanks</title>
                <style type="text/css">
                  
                        .content { font-size:12px; line-height:15px; color:#000000; letter-spacing:0.8px; padding-left: 40px; padding-right: 150px; }
                        .conbg { background-image: url(http://www.pocketbazar.net/theme_files/images/welcome.jpg); background-repeat: no-repeat; height: 427px; width: 611px; }
                        .writename{ color:#000000; font-size:12px; line-height:15px; padding-left:40px;}
                        .footertext { font-size:12px; color:#646363; }
                        .contenttit { font-size:12px; letter-spacing:1px; }
                        .STYLE1 { color: #0000FF }
                        a:link { color: #707070; text-decoration: underline; }
                        a:visited { color: #707070; text-decoration: underline; }
                        a:hover { color: #707070; text-decoration: none; }
                        a:active { color: #707070; text-decoration: underline; }
                        .style2 { font-size: 10px}
                        .style3 { font-size: 12px}
                        .style4 { font-size: 12}
                        .style5 { font-size: 14px; font-weight: bold; font-style: italic; color: #FF0000; }
                        .style6 { font-weight: bold}
                        .style7 { font-size: 12px; font-weight: bold; }
                        .style8 { color: #FF0000}
                  
                .style9 {font-size: 18}
                </style>
</head>
            <body>
                <table width="633" height="650" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td width="611" height="427" align="left" valign="top" class="conbg">
                            <table width="631">
                                <tr>
                                   
                                    <td width="623" height="563">  
                                      
                                        <p align="justify">
                                            <span class="style2">
                                                <span class="style3">
                                                    <span class="style4">
                                                        <span class="style6">
                                                            <em>
						<img src="http://pocketbazar.net//theme_files/images/logo.png" width="114" height="70">
                                                                <u>Welcome to Pocket Bazar </u>                                                            </em>
                                                            <br />
                                                            Thank you for joining the Solario Family. We wish every success towards our association.<br>
                                                            Your online office is  at <span class="style8">
															<a href="http://pocketbazar.net/">http://pocketbazar.net/</a></span>
                                                            <br />
                                                            Your access details  for login into the www.pocketbazar.net system are mentioned below:<br /><br />
                                                            <span class="style8">
                                                                Member ID: '.$userid.'<br />  
                                                                Password: '.$pwd.'<br />
                                                                Sponsor�s Name: '.$refuid.'</span>
                                                            <br />
                                                            <br />
                                                            Please contact your  sponsor for information, support and assistance with the  system and  business opportunity. They will be more than happy to assist you. This facility  is available through our messaging provision in the back-office.<br />
                                                            You can also an e-mail  us at <a href="mailto:support@solariorealty.com">support@/pocketbazar.net</a> for your queries.                                                        </span>                                                    </span>                                                </span>                                            </span>                                        </p>
                                        <p align="justify" class="style5">TEAM </p>
                                        <p align="justify" class="style7 style9">This is not a spam message. It is a system generated email sent through the SRCL notification system. You are receiving this message ,  being a current SRCL member. If you no longer wish to receive such messages  please contact�  to have your account closed.</p>                                  </td>
                                </tr>
                          </table>
                        </td>
                    </tr>
                </table>
            </body>
        </html>
';




?>





<?php /*?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Pocket Bazar</title>
<style type="text/css">

body {
  font-family:Tahoma;
}

img {
  border:0;
}

#page {
  width:800px;
  margin:0 auto;
  padding:15px;

}

#logo {
  float:left;
  margin:0;
}

#address {
  height:181px;
  margin-left:250px; 
}

table {
  width:100%;
}

td {
padding:5px;
}

tr.odd {
  background:#e1ffe1;
}
</style>
</head>
<body>


<div id="page">
  <div id="logo">
    <a href="http://pocketbazar.net/"><img src="http://www.danifer.com/images/invoice_logo.jpg"></a>
  </div><!--end logo-->
  
  <div id="address">

    <p>Pocketbazar.net<br />
    <a href="mailto:youremail@somewhere.com">youremail@somewhere.com</a>
    <br /><br />
    Invoice No # :123456<br />
    Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:2008-10-09<br />
    </p>
  </div><!--end address-->

  <div id="content">
    <p>
      <strong>Customer Details</strong><br />
      Name: Last, First<br />
      Email: customeremail@somewhere.com<br />
      Payment Type: MasterCard    </p>
    <hr>
    <table>
      <tr>
		  <td><strong>Description</strong></td>
		  <td><strong>Qty</strong></td>
		  <td><strong>Unit Price</strong></td>
		  <td><strong>Amount</strong></td>
	  </tr>
	  
      <tr class="odd">
	  <td>Product 1</td>
	  <td>1</td>
	  <td>4.95</td>
	  <td>4.95</td>
	  </tr>
	  
	  <tr class="even">
	  <td>Product 2</td>
	  <td>1</td>
	  <td>4.95</td>
	  <td>4.95</td>
	  </tr>
	  
	  <tr>
	  <td>&nbsp;</td><td>&nbsp;</td><td><strong>Total</strong></td>
	  <td><strong>14.85</strong></td>
	  </tr>

    </table>
    <hr>
    <p>
      Thank you for your order!  This transaction will appear on your billing statement as "Your Company".<br />
      If you have any questions, please feel free to contact us at <a href="mailto:youremail@somewhere.com">youremail@somewhere.com</a>.
    </p>

    <hr>
    <p>
      <center><small>This communication is for the exclusive use of the addressee and may contain proprietary, confidential or privileged information. If you are not the intended recipient any use, copying, disclosure, dissemination or distribution is strictly prohibited.
      <br /><br />
      &copy; Pocket bazar All Rights Reserved
      </small>
      </center>
    </p>
  </div><!--end content-->
</div><!--end page-->
</body>

</html><?php */?>