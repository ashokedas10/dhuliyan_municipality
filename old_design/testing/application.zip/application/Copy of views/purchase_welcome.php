
<img src="<?php echo BASE_PATH_FRONT?>/theme_files/images/thanks_banner_02.jpg" />

