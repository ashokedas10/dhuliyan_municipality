<form action="<?php echo BASE_URL?>cmscontaint/mailfunction/" method="post">
<div class="con">
<h2>Get in touch with Dhuliyan Municipality</h2>
<div class="conRow">
<div class="conLeft">Name :</div>
<div class="conRight"><input type="text" name="Name" class="in"></div>
</div>
<div class="conRow">
<div class="conLeft">Contact No :</div>
<div class="conRight"><input type="text" name="Mobile" class="in"></div>
</div>
<div class="conRow">
<div class="conLeft">Email ID :</div>
<div class="conRight"><input type="text" name="Email" class="in"></div>
</div>
<div class="conRow">
<div class="conLeft">Area :</div>
<div class="conRight"><input type="text" name="Area" class="in"></div>
</div>
<div class="conRow">
<div class="conLeft">Comment :</div>
<div class="conRight"><textarea name="Comment" class="inText" rows="" cols="" name=""></textarea></div>
</div>
<div class="conRow">
<div class="conLeft">&nbsp;</div>
<div class="conRight"><input type="submit" name="submit" value="Submit" class="but"></div>
</div>
<br class="clear">
</div>
</form>