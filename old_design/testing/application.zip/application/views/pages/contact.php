<style type="text/css">
<!--
.style1 {color: #CC3333}
-->
</style>

<div class="latest-heading"><span class="red-text">CONTACT US</span></div>
<P></P>
<div class="row">
   
		<div class="thumbnail">
		
			  <div class="caption">
					<ul class="list-group">
										
					  <li class="list-group-item list-group-item-success">
					  <h4 class="media-heading">CONTACT DETAILS</h4>
					  </li>
						
					  <li class="list-group-item list-group-item-info">
					  <div class="row" >
						 <div class="col-md-4">
						 <img src="<?php echo BASE_PATH_FRONT;?>theme_files/contactus.jpg" 
						 alt="" width="130" height="130" />
						 </div>
						 
						 <div class="col-md-8">
						 	<h3 class="style1">Dhuliyan Municipality</h3>
						 	<br />
							Phone No :03485- 266133<br />
							Fax No   :03485 - 265233<br />
							Mail Id  : dhuliyanmunicipality@gmail.com<br />
							info@dhuliyanmunicipality.in<br />
							
						 </div>
					  	
					  </div>
					  </li>
					  <li class="list-group-item list-group-item-warning"> </li>
					
					<!--MAP-->
					   <li class="list-group-item list-group-item-success">
					  <h4 class="media-heading">TRAVEL MAP</h4>
					  </li>
						
					  <li class="list-group-item list-group-item-info">
					  <div class="row" >
						  <iframe src="https://www.google.com/maps/embed?pb=!1m29!1m12!1m3!1d1871604.6854668097!2d86.97556021680354!3d23.623050362360882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m14!1i0!3e6!4m5!1s0x39f882db4908f667%3A0x43e330e68f6c2cbc!2sKolkata%2C+West+Bengal!3m2!1d22.572646!2d88.363895!4m5!1s0x39fa44c732a479d5%3A0x6357cad4fa85c61a!2sDhulian+Municipality%2C+Bidhan+Chandra+Road%2C+Jain+Colony%2C+Singh+Para%2C+Dhuliyan%2C+West+Bengal+742202!3m2!1d24.682548999999998!2d87.954612!5e0!3m2!1sen!2sin!4v1420355808852" width="100%" height="450" frameborder="0" style="border:0"></iframe>
					  	
					  </div>
					  
					  </li>
					  
					  <li class="list-group-item list-group-item-warning"> </li>
					  
					   <li class="list-group-item list-group-item-success">
					  <h4 class="media-heading">ENQUERY</h4>
					  </li>
						
					  <li class="list-group-item list-group-item-info">
					  <div class="row" >
						 <div class="col-md-3"></div>
						 
						 <div class="col-md-6">
						 	<form method="post" action="index.php" enctype="multipart/form-data">

<div align="left" class="style1" style="width:100px;padding-top:10px;float:left;font-family:Verdana, Geneva, sans-serif; font-size:11px;">
Your Fullname:</div>
<div style="width:300px; float:left;" align="left"><input type="text" id="vpbfullname" name="vpbfullname" value="" class="vpb_input_fields"></div><br clear="all"><br clear="all">


<div align="left" class="style1" style="width:100px;padding-top:10px;float:left;font-family:Verdana, Geneva, sans-serif; font-size:11px;">
Email Address:</div>
<div style="width:300px; float:left;" align="left"><input type="text" id="email" name="email" value="" class="vpb_input_fields"></div><br clear="all"><br clear="all">

<div align="left" class="style1" style="width:100px;padding-top:10px;float:left;font-family:Verdana, Geneva, sans-serif; font-size:11px;">
Email Subject:</div>
<div style="width:300px; float:left;" align="left"><input type="text" id="subject" name="subject" value="" class="vpb_input_fields"></div><br clear="all"><br clear="all">


<div align="left" class="style1" style="width:100px;padding-top:10px;float:left;font-family:Verdana, Geneva, sans-serif; font-size:11px;">
Your Message:</div>
<div style="width:300px; float:left;" align="left"><textarea id="message" name="message" style="width:280px; height:80px; padding:10px;" class="vpb_input_fields"></textarea></div><br clear="all"><br clear="all">


<br clear="all"><br clear="all">

<div style="width:420px; float:left;" align="left"><?php //echo $submission_status; ?></div><!-- Display success or error messages -->
<div style="width:100px; float:left;" align="left">&nbsp;</div>
<div style="width:300px; float:left;" align="left">
<input type="hidden" id="submitted" name="submitted" value="1">
<input type="submit" class="vpb_general_button"  value="Submit">
</div>


</form>
							
						 </div>
					  	 <div class="col-md-3"></div>
						 
					  </div>
					  </li>
					  <li class="list-group-item list-group-item-warning"> </li>
					  
					  
					</ul> 
				  </div>
			</div>
		
  	
  	
</div>

