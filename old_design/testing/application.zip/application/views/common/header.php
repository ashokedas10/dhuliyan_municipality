<!--header-starts-->
<div class="header">
	<div class="header_logo1">
	
	<table width="669">
	<tr><td  colspan="3">&nbsp;</td></tr>
  
	  <tr>
	  <td width="43">&nbsp;</td>
		<td width="118"><img src="<?php echo BASE_PATH_FRONT;?>theme_files/logo.png" alt="" width="118" height="99" /> </td>
		<td width="492"><embed src="<?php echo BASE_PATH_FRONT;?>theme_files/flash.swf" quality="high" type="application/x-shockwave-flash" wmode="transparent" width="492" height="101" pluginspage="http://www.macromedia.com/go/getflashplayer" allowScriptAccess="always"></embed></td>
	  </tr>
</table>
  </div>
	
	<div class="header_logo2">
	   <br />
		Mail ID : <span class="style1">
		dhuliyanmunicipality@gmail.com<br />info@dhuliyanmunicipality.in</span><br />
		Phone No. - <span class="style1">03485- 266133</span><br />
		Fax No.   - <span class="style1">03485 - 265233</span><br /><br />
		<strong><span class="style1"><span id="servertime"></span></strong>
		
	</div>
	
</div>
<!--header-ends-->

<!--nav starts-->
<div class="nav">
<div class="main">
	<ul>
		
	<?php /*?>	<?php foreach ($categorylist1 as $row){ ?>
		<li><a href="<?php echo BASE_URL?>cmscontaint/navigation/<?php echo $row->id;?>" ><?php echo strtoupper($row->cat_name); ?></a></li>
		<?php } ?>
		
		<?php foreach ($categorylist2 as $row){ ?>
<li><a href="<?php echo BASE_URL?>cmscontaint/navigation/<?php echo $row->id;?>" >
<?php echo strtoupper($row->cat_name); ?></a></li>
<?php } ?><?php */?>
		
<li><a href="<?php echo BASE_URL?>cmscontaint/">Home</a></li>
<li><a href="<?php echo BASE_URL?>cmscontaint/dmc/administrator/42">Administrtor</a></li>
<li><a href="<?php echo BASE_URL?>cmscontaint/dmc/tender">Tender</a></li>
<li><a href="<?php echo BASE_URL?>cmscontaint/dmc/department/44">Department</a></li>
<li><a href="<?php echo BASE_URL?>cmscontaint/dmc/service">Services</a></li>
<li><a href="<?php echo BASE_URL?>cmscontaint/dmc/projects/48">Projects</a></li>
<li><a href="http://dhuliyanmunicipality.in/nsap.html">NSAP</a></li>
<li class="no-border"><a href="<?php echo BASE_URL?>cmscontaint/dmc/contact">Contact Us</a></li>
		
		
	</ul>
	<div class="clearBoth"></div>
</div>
</div>
<!--nav ends-->