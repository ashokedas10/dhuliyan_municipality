<?php /*?><!--banner starts-->
<div class="banner">
	<div id="wowslider-container1">
		<div class="ws_images">
			<ul>
		
			
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner2.jpg" alt="banner" title="" /></li>
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner3.jpg" alt="banner" title="" /></li>
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner4.jpg" alt="banner" title="" /></li>
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner5.jpg" alt="banner" title="" /></li>
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner6.jpg" alt="banner" title="" /></li>
			<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/banner/banner8.jpg" alt="banner" title="" /></li>
			
				
			</ul>
		</div>
	</div>
</div><?php */?>



 <!--banner starts-->
        <div class="banner">
        	<div id="wowslider-container1">
                <div class="ws_images">
                	<ul>
					
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner2.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner3.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner4.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner5.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner6.jpg" alt="banner" title="" /></li>
				<li><img src="<?php echo BASE_PATH_FRONT;?>theme_files/dhuliyan_images/banner/banner8.jpg" alt="banner" title="" /></li>
						
						
                    </ul>
                </div>
            </div>
        </div>
        <!--banner ends-->
<!--banner ends-->