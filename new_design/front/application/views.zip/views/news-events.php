 <!--Page Title-->
 <section class="page-title" style="background-image:url(images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>News & Events</h1>
                <div class="bread-crumb"><a href="index.html">Home</a> / <a href="#" class="current">News & Events</a></div>
            </div>
        </div>
    </section>
    
    
    <!--Events Section-->
    <section class="events-section latest-events">
    	<div class="auto-container">
        	
        	
			
                <?php foreach($records as $record) { ?>
				
					<div class="row" style="padding-bottom:20px;">
		
						  <div class="col-sm-2 col-md-2">
							<div class="thumbnail">
							<img src="<?php echo BASE_PATH.'admin/uploads/'.$record->news_pic;?>" alt="" >
							</div>
						  </div>
		  
							<div class="col-sm-10 col-md-10">
								<div class="bg-primary">
								  <h3 style="padding-left:20px;"><?php echo $record->date; ?> <?php echo '  | '.$record->title; ?></h3>
								</div>
								<div class="caption"><?php echo $record->news_details; ?></div>
							</div>
								 <?php /*?><div class="column-info"><?php echo $record->date; ?> <?php echo '  | '.$record->title; ?> </div>
								 <div class="caption"><div class="text"><?php echo $record->news_details; ?></div><?php */?>
						   
					  </div>
			  				
				 <?php } ?>           
                        
        </div>
    </section>