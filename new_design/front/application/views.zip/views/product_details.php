<script type="text/javascript">

$(".modal-wide").on("show.bs.modal", function() {
  var height = $(window).height() - 200;
  $(this).find(".modal-body").css("max-height", height);
});


</script>
<style>

div.ex1 {
  background-color: lightblue;
  width: 100%;
  height: 200px;
  overflow: scroll;
}



.activeTR {  
	background-color: yellow;
    color:black;	
    font-weight:bold;
}

</style>
<style type="text/css">

.style2 {
	color: #990000;
	font-weight: bold;
	font-size:18px;
}


.modal.modal-wide .modal-dialog {
  width: 90%;
}
.modal-wide .modal-body {
  overflow-y: auto;
}

/* irrelevant styling */

body p { 
 /* max-width: 400px; 
  margin: 20px auto; 
  margin-bottom: 400px*/
}
#tallModal .modal-body p { margin-bottom: 900px }

</style>
  
  
  
  
<style>
/*body {
  padding: 20px;
  font-family: sans-serif;
  background: #f2f2f2;
}*/
img {
  width: 100%; /* need to overwrite inline dimensions */
  height: auto;
}
h2 {
  margin-bottom: .5em;
}
.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  grid-gap: 1em;
}


/* hover styles */
.location-listing {
  position: relative;
}

.location-image {
  line-height: 0;
  overflow: hidden;
}

.location-image img {
  filter: blur(0px);
  transition: filter 0.3s ease-in;
  transform: scale(1.1);
}

.location-title {
  font-size: 1.5em;
  font-weight: bold;
  text-decoration: none;
  z-index: 1;
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  opacity: 0;
  transition: opacity .5s;
  background: rgba(90,0,10,0.4);
  color: white;
  
  /* position the text in t� middle*/
  display: flex;
  align-items: center;
  justify-content: center;
}

.location-listing:hover .location-title {
  opacity: 1;
}

.location-listing:hover .location-image img {
  filter: blur(2px);
}


/* for touch screen devices */
@media (hover: none) { 
  .location-title {
    opacity: 1;
  }
  .location-image img {
    filter: blur(2px);
  }
}
</style>
    
  <!--Page Title-->
    <section class="page-title"   style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1><?php echo $product_category; ?> <span class="normal-font"></span></h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">Products</a></div>
            </div>
        </div>
    </section>
	
	 <section class="events-section latest-events">
    	<div class="auto-container">
		
		<div class="row clearfix" style="padding-bottom:20px;">
		<?php 
			 foreach ($records as $record){ 
			 if($record->image<>''){
			 ?>	
		<div class="row clearfix" style="padding-bottom:20px;">
		
			   <div class="col-sm-6 col-md-4">
				<div class="thumbnail"><img src="<?php echo BASE_PATH.'admin/uploads/'.$record->image;?>" style="width:100%; height:300px; "></div>
			  </div>
			  <div class="col-sm-6 col-md-8">
			 		 <div class="bg-primary">
					  <h3 style="padding-left:20px;"><?php  echo $record->name; ?></h3>
					</div>
				<div class="caption">
					
					
					<p align="justify"><?php  echo $record->service_details; ?></p>
					<div align="justify">
					  <?php /*?><p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p><?php */?>
				      </div>
				  </div>
			  </div>
			  
			</div>
		
		<?php }} ?>
		</div>
	</div>	
	
	</section>
	
	<br>
	   
    
    
    <!--Intro Section-->
   <section class="subscribe-intro">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column col-md-9 col-sm-12 col-xs-12">
                	<h2>Get in Touch</h2>
                    For any product related query please feel free to contact us
                </div>
                <!--Column-->
                <div class="column col-md-3 col-sm-12 col-xs-12">
                	<div class="text-right padd-top-20">
                		<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/" class="theme-btn btn-style-one">Leave Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	
	<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
