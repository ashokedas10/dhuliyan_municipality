<!--Page Title-->
<section class="page-title" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>Contact <span class="normal-font">Us</span></h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">Contact Us</a></div>
            </div>
        </div>
</section>
    
    
    <!--Default Section / Other Info-->
    <section class="default-section other-info">
    	<div class="auto-container">
        
        	<div class="row clearfix">
                
                <!--Info Column-->
                <div class="column info-column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box">
                		<h3 class="margin-bott-20">Office Address</h3>
                		<div align="justify">
                		  <p><strong>BANKIM PROSAD GHOSH SEEDS PVT LTD</strong><br />
                		    11/2,Kailash Chandra Singha Lane ,<strong> P.O</strong>:&nbsp;Bally,&nbsp;<strong>Dist:</strong>Howrah,&nbsp;<strong>Pin-</strong>&nbsp;711201
							<br />West Bengal, India.</p>
              		  </div>
                		
                		<div align="justify"><span class="icon flaticon-technology-5"></span>&nbsp;91-33-2654-2095/2422<br />
                		    <strong>Telefax:&nbsp;</strong>91-33-2654-2445<br />
                		  <span class="icon flaticon-interface-1"></span>&nbsp;&nbsp;<a href="mailto:info@bankimseed.com">info@bankimseed.com</a></div>
                		<p class="margin-bott-20">&nbsp;</p>
						
                		<?php /*?><ul class="info-box">
                            <li><span class="icon flaticon-location"></span><strong>Address</strong> Test Adddress New Bazar Road, Block-c, Country</li>
                            <li><span class="icon flaticon-technology-5"></span><strong>Phone</strong> (732) 803-01 03, (732) 806-01 04</li>
                            <li><span class="icon flaticon-interface-1"></span><strong>Email</strong> smaple@gmail.com</li>
                        </ul><?php */?>
                    </article>
					
					<article class="inner-box" >
                		<h3 class="margin-bott-20">Farm Address</h3>
                		<div align="justify">6 Nemai Tirtha Road,
                		  <strong>P.O:</strong>&nbsp;Baidybati,&nbsp;<strong>Dist:</strong>&nbsp;Hoogly,
               		    <strong>Pin-</strong>&nbsp;712222,<br /> West Bengal,India</div>
                		
                		<div align="justify"><span class="icon flaticon-technology-5"></span>&nbsp;91-33-2632-0640<br />
                		<p class="margin-bott-20">Distance from City : 26km.</p>
						</div>
                    </article>
                </div>
                
                <!--Image Column-->
                <div class="column image-column col-lg-7 col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box contact-form">
                        <form method="post" action="http://world5.commonsupport.com/html/greenture-new/sendemail.php" id="contact-form">
                            <div class="row clearfix">
                                <!--Form Group-->
                                <div class="form-group col-md-6 col-xs-12">
                                    <input type="text" name="username" value="" placeholder="Your Name">
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-6 col-xs-12">
                                    <input type="text" name="email" value="" placeholder="Your Email">
                                </div>
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-xs-12">
                                    <textarea name="message" placeholder="Message"></textarea>
                                </div>
                                
                                <!--Form Group-->
                                <div class="form-group col-md-12 col-xs-12">
                                    <div class="text-right"><button type="submit" class="theme-btn btn-style-two">Send</button></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            
            </div>
        </div>
    </section>
    
    
    <!--Contact Section-->
    <section class="contact-section no-padd-top">
    	<div class="auto-container">
        
        	<div class="row clearfix">
                
                <!--Map Column-->
                <div class="column map-column col-lg-12 col-md-12 col-sm-12 col-xs-12">
                	<h2>Our Location on Map</h2>
					
					 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7364.609699959538!2d88.34262162455728!3d22.64241979058749!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f89d1749eea9b1%3A0xb5cdff20b6257eac!2sBANKIM%20PROSAD%20GHOSH%20SEEDS%20PVT%20LTD!5e0!3m2!1sen!2sin!4v1572793530948!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
                
                
            
            </div>
        </div>
    </section>
    