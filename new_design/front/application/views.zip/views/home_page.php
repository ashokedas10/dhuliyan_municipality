 <!--Main Slider-->
    <section class="main-slider revolution-slider">
    	
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>
                	
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo BASE_PATH_ADMIN;?>theme_files/images/main-slider/1.jpg"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/main-slider/1.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    
                    <!--<div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-150"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="circular-drop">0<sub>2</sub></div></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="90"
                    data-y="center" data-voffset="-50"
                    data-speed="1500"
                    data-start="1000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h1><span class="normal-font">Go</span> Green</h1></div>-->
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="90"
                    data-y="center" data-voffset="10"
                    data-speed="1500"
                    data-start="1500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h3 class="bg-color">Welcome to Bankim Seeds</h3></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="90"
                    data-y="center" data-voffset="90"
                    data-speed="1500"
                    data-start="2000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="text">The year 1920 was momentous in the history of BankimProsadGhosh Seeds <br>
					A small seedcompany with a big vision took birth.</div></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="90"
                    data-y="center" data-voffset="190"
                    data-speed="1500"
                    data-start="2000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/about/" class="theme-btn btn-style-one">Learn More</a></div>
                    
                    </li>
                    
                    <li data-transition="slidedown" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo BASE_PATH_ADMIN;?>theme_files/images/main-slider/2.jpg"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/main-slider/2.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    
                    <!--<div class="tp-caption sfl sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="-120"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2 class="normal-font">Help us</h2></div>-->
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="-30"
                    data-speed="1500"
                    data-start="1000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>Bankim Seeds</h2></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="50"
                    data-speed="1500"
                    data-start="1500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h4>We have almost 100  years experience in the vegetable seed production business.</h4></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="center" data-hoffset="0"
                    data-y="center" data-voffset="120"
                    data-speed="1500"
                    data-start="2000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ResearchAndDevelopment/" class="theme-btn btn-style-one">
					Learn More</a></div>
                    </li>
                    
                    
                    
                    
                </ul>
                
            </div>
        </div>
    </section>
    
    
    <!--Main Features-->
	<?php  if(sizeof($products)>0){?>
	
    <section class="main-features">
    	<div class="auto-container">
        	<div class="title-box text-center">
            	<h2>Our Best Selling Seeds</h2>
                <div class="text">-------------------------------------------------------------------</div>
            </div>
			
            <div class="row clearfix">
                <!--Feature Column-->
				<?php  foreach ($products as $product){if($product->image<>''){?>					
					<div class="features-column col-lg-3 col-md-6 col-xs-12">
						<article class="inner-box">
							<img src="<?php echo BASE_PATH.'admin/uploads/'.$product->image;?>"  style="width:100%; height:200px;border-radius: 100%; 
							border:6px solid #6ac610">
							<h4 class="title" align="center"><?php  echo $product->name; ?></h4>
						</article>
					</div>				
				<?php }} ?>
            </div>
        </div>
    </section>
    
    <?php }?>
	
    <!--Featured Fluid Section-->
    <section class="featured-fluid-section">
    	
        
    	<div class="outer clearfix">
            
            <!--Image Column-->
            <div class="image-column" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/fluid-image-1.jpg);"></div>
            
            <!--Text Column-->
            <article class="column text-column dark-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/fluid-image-2.jpg);">
                
                <div class="content-box pull-left">	
                    <h2>Welcome to <span class="theme_color">Bankim Seeds</span></h2>
                    <div class="text">The year 1920 was momentous in the history of Bankim Prosad Ghosh Seeds. A small seed company with a big vision ........</div>
                    <a href="<?php echo BASE_PATH_ADMIN;?>Seeds/about/" class="theme-btn btn-style-two">Read More About Us</a>
					<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/Products/" class="theme-btn btn-style-one">View Products</a>
                    
                </div>
                
                <div class="clearfix"></div>
            </article>
            
        </div>
        
    </section>
    
   		
    <!--Blog News Section-->
	<?php  if(sizeof($latest_news)>0){?>
	
    <section class="blog-news-section latest-news">
        <div class="auto-container">
            
            <div class="sec-title text-center">
                <h2>Latest <span class="normal-font theme_color">News</span></h2>
                <div class="text">**************************************</div>
            </div>
            <div class="row clearfix">
                
				<?php  foreach ($latest_news as $news){?>
									
					 <div class="column blog-news-column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <article class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <figure class="image-box">
                           <img src="<?php echo BASE_PATH.'admin/uploads/'.$news->news_pic;?>" alt="" style="width:100%; height:300px;">
                            <div class="news-date"><?php echo substr($news->date,8,2); ?> <span class="month">
							<?php echo substr($this->general_library->monthcal($news->date),0,3); ?></span></div>
                        </figure>
                        <div class="content-box">
                            <h3><a href="#"><?php echo $news->title; ?></a></h3>
                          <!--  <div class="post-info clearfix">
                                <div class="post-author">Posted by Admin</div>
                                <div class="post-options clearfix">
                                    <a href="#" class="comments-count"><span class="icon flaticon-communication-2"></span> 6</a>
                                    <a href="#" class="fav-count"><span class="icon flaticon-favorite-1"></span> 14</a>
                                </div>
                            </div>-->
                            <div class="text">
							<?php echo substr($news->news_details,0,80).'....'; ?>
							</div>
                            <a href="<?php echo BASE_PATH_ADMIN;?>Seeds/NewsEvents/" class="theme-btn read-more">Read More</a>
                        </div>
                    </article>
                </div>			
				<?php } ?>
				
                <!--News Column-->
               
                                
            </div>
        </div>
    </section>
    
	<?php  }?>
    
    <!--Two Column Fluid -->
    <section class="two-column-fluid">
    	
        
    	<div class="outer clearfix">
        	
            
            <article class="column left-column" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/fluid-image-3.jpg);">
                
                <div class="content-box pull-right">	
                    <h2>Research &<span class="normal-font theme_color">Development</span></h2>
                    <div class="text">Research & Development is a continuous  process at Bankim Seeds . In last 100 years of existence , we have identified many farmer�s variety which are further used for varietal development and breeding activity.</div>
                    <br>
                    <a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ResearchAndDevelopment/" class="theme-btn btn-style-two">Read More</a>
                    
                </div>
                
                <div class="clearfix"></div>
            </article>
            
            <article class="column right-column" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/fluid-image-4.jpg);">
                
                <div class="content-box pull-left">	
                	<div class="outer-box">
                    	<div class="quote-icon"><span class="fa fa-quote-left"></span></div>
                        <h2>Contract Seed<span class="normal-font">  Production</span></h2>
                        
                        <!--Text Content-->
                        <div class="text-content">
                            <div class="text"><p>We have almost 100  years experience in the vegetable seed production business. We specialize in the production of seeds of  tropical vegetable crops and our emphasis is to deliver  quality seeds maintain  physical and genetic purity of highest order. </p></div>
                            <a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ContractSeedProduction/" class="theme-btn btn-style-one">Read More</a>
                            
                        </div>
                        
                    </div>
                </div>
                
                <div class="clearfix"></div>
            </article>
            
        </div>
        
    </section>
    
   
    <!--Testimonials-->
<?php /*?>    <section class="testimonials-section" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/testimonials-bg.jpg);">
		<div class="auto-container">
            
            <div class="sec-title text-center">
                <h2>Testi<span class="normal-font theme_color">Monials</span></h2>
                <div class="text">Lorem ipsum dolor sit amet, cum at inani interes setnisl omnium dolor amet amet qco modo cum text </div>
            </div>
            
            <!--Slider-->      
        	<div class="testimonials-slider testimonials-carousel">
            	
                <!--Slide-->
                <article class="slide-item">
                	
                    <div class="info-box">
                    	<figure class="image-box"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/testi-image-1.jpg" alt=""></figure>
                    	<h3>Mark Pine</h3>
                        <p class="designation">Rome, Italy</p>
                    </div>
                    
                    <div class="slide-text">
                        <p>�But I must explain to you the how all this mistaken idea of thealorem qco denouncing pleasure�</p>
                    </div>
                </article>
                
                <!--Slide-->
                <article class="slide-item">
                	
                    <div class="info-box">
                    	<figure class="image-box"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/testi-image-2.jpg" alt=""></figure>
                    	<h3>Mark Pine</h3>
                        <p class="designation">Rome, Italy</p>
                    </div>
                    
                    <div class="slide-text">
                        <p>�But I must explain to you the how all this mistaken idea of thealorem qco denouncing pleasure�</p>
                    </div>
                </article>
                
                <!--Slide-->
                <article class="slide-item">
                	
                    <div class="info-box">
                    	<figure class="image-box"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/testi-image-3.jpg" alt=""></figure>
                    	<h3>Mark Pine</h3>
                        <p class="designation">Rome, Italy</p>
                    </div>
                    
                    <div class="slide-text">
                        <p>�But I must explain to you the how all this mistaken idea of thealorem qco denouncing pleasure�</p>
                    </div>
                </article>
                
                
            </div>
            
        </div>    
    </section><?php */?>
    
    
    <!--Sponsors Section-->
 <?php /*?>   <section class="sponsors-section">
        <div class="sec-title text-center">
            <h2>Our <span class="normal-font theme_color">Clients</span></h2>
            <div class="text">-------------------------------------------------------</div>
        </div>
        <div class="auto-container">
            <div class="slider-outer">
                <!--Sponsors Slider-->
                <ul class="sponsors-slider">
                    <li><a href="#"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/clients/1.jpg" alt=""></a></li>
                    <li><a href="#"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/clients/2.jpg" alt=""></a></li>
                    <li><a href="#"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/clients/3.jpg" alt=""></a></li>
                    <li><a href="#"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/clients/4.jpg" alt=""></a></li>
                    <li><a href="#"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/clients/2.jpg" alt=""></a></li>
                </ul>
            </div>
            
        </div>
    </section><?php */?>
    
  