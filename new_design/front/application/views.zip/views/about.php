<!--Page Title-->
<section class="page-title" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>About Us</h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">About Us</a></div>
            </div>
        </div>
    </section>
    
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
                
                <!--Column-->
             <!--   <div class="column image-column col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<figure class="image-box video-box">
                        	<img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/video-image-1.jpg" alt="">
                        </figure>
                    </article>
                </div>-->
                
                <!--Column-->
                <div class="column default-text-column with-margin col-md-12 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<h2>Welcome to <span class="theme_color normal-font">Bankim Seed</span></h2>
                        
                        <div class="text">
                            <p align="justify">The  year 1920 was momentous in the history of BankimProsadGhosh Seeds. A small  seedcompany with a big vision took birth. Mr. Bankim Prasad Ghosh who could see  the place of
quality  seeds to raise agricultural production and also its role in uplifting the  farmers'economic status had sensed a business opportunity in it. His  entrepreneurial spirit beaconedhim to plunge into the world of immense  possibility. He mastered courage and the fear offailure did not deter him. He  went ahead in founding BankimProsadGhosh seeds in an auspicious  date of 15th April ,1920 coinciding with the 1st day of Bengali New Year which  isknown as NABABARSHA</p>

                            <p align="justify">He  started importing high-quality vegetable seeds from abroad and sell them to the  Indianfarmers. Subsequently, he took up quality seed production indigenously.  His passion toproduce and supply quality seeds to the farmers made him famous  in no time. BankimProsadGhosh Seeds kept moving forward year after year and  there was no looking back. Hehad no college or university degree but what he  had was priceless, a seedsman by heart. Hispassion to produce quality seeds and  supply the same to the farmers at most reasonable prices  had never wavered.</p>
                           
                            <p align="justify">In  1960 the baton was passed on to the hands of his son, Mr. ByomkeshGhosh. The  era ofmodernization began. The company's product portfolios increased,  distribution networkexpanded, storage system modernized, processing and  packaging system upgraded andmany other progressive measures were taken to  establish Bankim seeds as a brand whichthe farmers can rely upon.</p>
                           
                            <p align="justify">In  1980&nbsp; Mr. BiswanathGhosh took over from  his father Mr. ByomkeshGhosh and beingeducated in agricultural sciences he  could bring in new focus to the business. He placedgreat emphasis on brand  building and soon Bankim seeds became a household name amongthe farmers in  Eastern India and came to be known as Jute king of Bengal. On the exportfront,  the company made a great stride in South East Asia with a dominant footprint  inBangladesh market. To be in tune with time and to maintain the competitive  edge, thecompany subsequently set up 30 acres of R &amp; D farm close to  Kolkata city. On thediversification front, A Nursery farm was also set up on a  commercial scale .</p>
                           
                            <p align="justify">In  2015 with the demise of Mr.BiswanathGhosh, the responsibility of running the  companyautomatically fell into the hands of his two sons. 4th generation  activity started with a newfocus. Mr.SudiptaGhosh the elder one who has a  master degree in seed science and Mr.ArindamGhosh the younger one with an MBA  have been now spearheading the company totake it to a new phase. A family-run  seed company so far is now decentralized in all itsareas . Professionally  qualified and experienced executives today run the company underthe able  leadership of the two brothers MrSudiptaGhosh and MrArindamGhosh.</p>
                          
                            <p align="justify">Everything  done in Bankim seeds is high tech and , TRUST AT THE CORE as enunciated bythe  founding father is not only adhered to but respected in all levels of the  operations ofthe company.</p>
                            <p align="justify">Since  1920 the company has passed through various stages of ups and downs but never  lostits sight to supply quality seeds to the farmers. Possibly this is one  single reason why thecompany has survived so long for almost 100 years and  still moving ahead with a greatpromise. There are possibly not many such  examples of long-surviving seed companies inthe history of the world seed  business.</p>
                      </div>
                        
                    </article>
                </div>
                
            </div>
            
            
            
        </div>
    </section>
    
    
    <!--Intro Section-->
    <section class="subscribe-intro">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column col-md-9 col-sm-12 col-xs-12">
                	<h2>Get in Touch</h2>
                    For any product related query please feel free to contact us
                </div>
                <!--Column-->
                <div class="column col-md-3 col-sm-12 col-xs-12">
                	<div class="text-right padd-top-20">
                		<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/" class="theme-btn btn-style-one">Leave Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	