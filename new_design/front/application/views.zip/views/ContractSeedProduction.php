<!--Page Title-->
<section class="page-title" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>Contract Seed Production</h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">Contract Seed Production</a></div>
            </div>
        </div>
    </section>
    
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
                
                <!--Column-->
                <div class="column image-column col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<figure class="image-box video-box">
                        	<img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/contract_seed_production.jpg" alt="">
                        </figure>
                    </article>
                </div>
                
                <!--Column-->
                <div class="column default-text-column with-margin col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<h2>Welcome to <span class="theme_color normal-font">Bankim Seed</span></h2>
                        
                        <div class="text">
                            <p align="justify">We have almost 100 &nbsp;years experience in the vegetable seed  production business. We specialize in the production of seeds of &nbsp;tropical vegetable crops and our emphasis is  to deliver &nbsp;quality seeds maintain &nbsp;physical and genetic purity of highest order. 
                            Overseas customers can bank on our century old  credibility in terms of maintaining of&nbsp; secrecy  of their varieties and stock seed when entrusted to us. Periodic reports and  updates are shared with our customers during critical development stage of  vegetable seeds for Seed Production.<br>
                            <br>
Our Seed Production base is spread across India keeping in mind that different
crops  needs different agro-climatic conditions. Our main production base are spread  across states of West Bengal ,Andra Pradesh , Karnataka , Punjab ,&nbsp; Uttar Pradesh , Rajasthan , Gujrat&amp;  Maharashtra . With a hard core of efficient seed growers under wide range of  agro climate conditions in different parts of the country, it is possible to  produce seed almost throughout the year in the relatively disease free  environment.We ensure that your stock seed is grown to its fullest potential by  highly experienced growers.
<p align="justify">&nbsp;</p>

                      </div>
                        
                    </article>
                </div>
                
            </div>
            
            
            
        </div>
    </section>
    
    
    <!--Intro Section-->
    <section class="subscribe-intro">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column col-md-9 col-sm-12 col-xs-12">
                	<h2>Get in Touch</h2>
                    For any product related query please feel free to contact us
                </div>
                <!--Column-->
                <div class="column col-md-3 col-sm-12 col-xs-12">
                	<div class="text-right padd-top-20">
                		<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/" class="theme-btn btn-style-one">Leave Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	