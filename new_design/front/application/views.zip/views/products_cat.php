
  <!--Page Title-->

    <section class="page-title"   style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>Our <span class="normal-font">Products</span></h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">Products</a></div>
            </div>
        </div>
    </section>

	 <section class="events-section latest-events">
	 
        <div class="auto-container">
			
			<div class="row clearfix" style="padding-bottom:20px;">
						
			 <?php foreach ($records as $record){ if($record->image<>''){?>			
				
				  <div class="col-sm-6 col-md-4">
						
						<div class="thumbnail">
							 <a  href="<?php echo BASE_PATH_ADMIN;?>Seeds/Products_detail/<?php echo $record->id;?>">
							 <img  src="<?php echo BASE_PATH.'admin/uploads/'.$record->image;?>" 
							 alt="<?php echo $record->cate_name ?>"  style="width:100%; height:300px;"></a>
						</div>
						
						<div class="caption" >
							<div class="alert alert-danger" role="alert">
							<h4 align="center"><strong><?php echo $record->cate_name ?></strong></h4>
							</div>
						</div>	
				 </div>
			 
			  <?php }} ?>
			  </div>

		</div>	

	</section>

	

	<br>

	   

    

    

    <!--Intro Section-->

   <section class="subscribe-intro">

    	<div class="auto-container">

        	<div class="row clearfix">

            	<!--Column-->

                <div class="column col-md-9 col-sm-12 col-xs-12">

                	<h2>Get in Touch</h2>

                    For any product related query please feel free to contact us

                </div>

                <!--Column-->

                <div class="column col-md-3 col-sm-12 col-xs-12">

                	<div class="text-right padd-top-20">

                		<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/" class="theme-btn btn-style-one">Leave Message</a>

                    </div>

                </div>

            </div>

        </div>

    </section>

	

	

	<script>

filterSelection("all")

function filterSelection(c) {

  var x, i;

  x = document.getElementsByClassName("column");

  if (c == "all") c = "";

  for (i = 0; i < x.length; i++) {

    w3RemoveClass(x[i], "show");

    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");

  }

}



function w3AddClass(element, name) {

  var i, arr1, arr2;

  arr1 = element.className.split(" ");

  arr2 = name.split(" ");

  for (i = 0; i < arr2.length; i++) {

    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}

  }

}



function w3RemoveClass(element, name) {

  var i, arr1, arr2;

  arr1 = element.className.split(" ");

  arr2 = name.split(" ");

  for (i = 0; i < arr2.length; i++) {

    while (arr1.indexOf(arr2[i]) > -1) {

      arr1.splice(arr1.indexOf(arr2[i]), 1);     

    }

  }

  element.className = arr1.join(" ");

}





// Add active class to the current button (highlight it)

var btnContainer = document.getElementById("myBtnContainer");

var btns = btnContainer.getElementsByClassName("btn");

for (var i = 0; i < btns.length; i++) {

  btns[i].addEventListener("click", function(){

    var current = document.getElementsByClassName("active");

    current[0].className = current[0].className.replace(" active", "");

    this.className += " active";

  });

}

</script>