<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $page_title; ?></title>
<!-- Stylesheets -->
<link href="<?php echo BASE_PATH_ADMIN;?>theme_files/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo BASE_PATH_ADMIN;?>theme_files/css/revolution-slider.css" rel="stylesheet">
<link href="<?php echo BASE_PATH_ADMIN;?>theme_files/css/style.css" rel="stylesheet">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="<?php echo BASE_PATH_ADMIN;?>theme_files/css/responsive.css" rel="stylesheet">
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->



</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
  <!--  <div class="preloader"></div>-->
    
	 <!-- Main Header -->
  	<?php echo $header; ?>	
     <!--End Main Header -->
	  
	<?php echo $body; ?>
    <!--Main Footer-->
 	<?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->


<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="fa fa-long-arrow-up"></span></div>


<!--Donate Popup-->
<div class="modal fade pop-box" id="donate-popup" tabindex="-1" role="dialog" aria-labelledby="donate-popup" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        	<!--Donation Section-->
            <section class="donation-section">
                <div class="donation-form-outer">
                    <form method="post" action="http://world5.commonsupport.com/html/greenture-new/contact.html">
                        
                        <!--Form Portlet-->
                        <div class="form-portlet">
                            <h4>Leave us a Message</h4>
                            
                            <div class="row clearfix">
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">First Name <span class="required">*</span></div>
                                    <input type="text" name="name" value="" placeholder="First Name" required>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Email <span class="required">*</span></div>
                                    <input type="email" name="name" value="" placeholder="Email" required>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Phone <span class="required">*</span></div>
                                    <input type="text" name="name" value="" placeholder="Phone" required>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Subject <span class="required">*</span></div>
                                    <input type="text" name="name" value="" placeholder="Subject" required>
                                </div>
                                
                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Message <span class="required">*</span></div>
                                    <textarea class="from-control" rows="4"></textarea>
                                </div>

                            </div>
                        </div>
                        
                        <div class="text-left"><button type="submit" class="theme-btn btn-style-two">Send Message</button></div>
                        
                    </form>
                </div>
            </section>
        </div>
    <!-- /.modal-content -->
    </div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/jquery.js"></script> 
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/revolution.min.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/jquery.fancybox.pack.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/jquery.fancybox-media.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/owl.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/wow.js"></script>
<script src="<?php echo BASE_PATH_ADMIN;?>theme_files/js/script.js"></script>
</body>
</html>