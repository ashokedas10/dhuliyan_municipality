
   <footer class="main-footer" style="background-image:url(images/background/footer-bg.jpg);">
    	
        <!--Footer Upper-->        
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                	
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">
                            <div class="col-lg-8 col-sm-6 col-xs-12 column">
                                <div class="footer-widget about-widget">
                                    <div class="logo"><a href="index-2.html"><img src="images/logo-2.png" class="img-responsive" alt=""></a></div>
                                    
									
                                    
                                    <ul class="contact-info">
									<h2>Address and Contact</h2>
                                    	<li><span class="icon fa fa-map-marker"></span>11/2,Kailash Chandra Singha Lane 
										<strong> P.O</strong>:&nbsp;Bally,&nbsp;<strong>Dist:</strong>Howrah,&nbsp;<strong>Pin-</strong>&nbsp;711201
										<br />West Bengal, India.</li>
                                        <li><span class="icon fa fa-phone"></span> 91-33-2654-2095/2422</li>
                                        <li><span class="icon fa fa-envelope-o"></span> <a href="mailto:info@bankimseed.com">info@bankimseed.com</a></li>
                                    </ul>
                                    
                                    <div class="social-links-two clearfix">
									
                                    	<a href="#" class="facebook img-circle"><span class="fa fa-facebook-f"></span></a>
                                        <a href="#" class="twitter img-circle"><span class="fa fa-twitter"></span></a>
                                        <a href="#" class="google-plus img-circle"><span class="fa fa-google-plus"></span></a>
                                        <a href="#" class="linkedin img-circle"><span class="fa fa-pinterest-p"></span></a>
                                        <a href="#" class="linkedin img-circle"><span class="fa fa-linkedin"></span></a>
                                    </div>
                                    
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="col-lg-4 col-sm-6 col-xs-12 column">
                                <h2>Quick Links</h2>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li ><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a></li>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/about/">About Us</a></li>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ResearchAndDevelopment/">R & D</a></li>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ContractSeedProduction/">Contract Seed Production</a></li>
										 <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/Products/">Products</a></li>
										<li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/NewsEvents/">News & Events</a></li>
										<li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/">Contact Us</a></li>
                                    </ul>
        
                                </div>
                            </div>
                    	</div>
                    </div><!--Two 4th column End-->
                    
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    	<div class="row clearfix">

                            <!--Footer Column-->
                           <!-- <div class="col-lg-5 col-sm-6 col-xs-12 column">
                                <div class="footer-widget links-widget">
                                    <h2>Products</h2>
                                    <ul>
                                        <li><a href="#">Product Category One</a></li>
                                        <li><a href="#">Product Category Two</a></li>
                                        <li><a href="#">Product Category Three</a></li>
                                        <li><a href="#">Product Category Four</a></li>
                                    </ul>
        
                                </div>
                            </div>-->
                    		<!--Footer Column-->
                        	<div class="col-lg-7 col-sm-6 col-xs-12 column">
                            	<div class="footer-widget news-widget">
                                	<h2>Locate Us</h2>	
                                     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7364.609699959538!2d88.34262162455728!3d22.64241979058749!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f89d1749eea9b1%3A0xb5cdff20b6257eac!2sBANKIM%20PROSAD%20GHOSH%20SEEDS%20PVT%20LTD!5e0!3m2!1sen!2sin!4v1572793530948!5m2!1sen!2sin" width="100%" height="250" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
									 
                            
                                    
                                </div>
                            </div>
                            
                            
                    	</div>
                    </div><!--Two 4th column End-->
                    
                </div>
                
            </div>
        </div>
        
        <!--Footer Bottom-->
    	<div class="footer-bottom">
            <div class="auto-container clearfix">
                <!--Copyright-->
                <div class="copyright text-center">Copyright 2019 &copy; Bankim Seed.</div>
            </div>
        </div>
        
    </footer>