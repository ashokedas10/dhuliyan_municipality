   
	    <!-- Main Header -->
    <header class="main-header">
    	<div class="top-bar">
        	<div class="top-container">
            	<!--Info Outer-->
                 <div class="info-outer">
                 	<!--Info Box-->
                    <ul class="info-box clearfix">
                    	<li><span class="icon flaticon-interface"></span><a href="mailto:info@bankimseed.com">info@bankimseed.com</a></li>
                    	<li><span class="icon flaticon-technology-5"></span>91-33-2654-2095/2422</li>
                        <li class="social-links-one">
                        	<a href="#" class="facebook img-circle"><span class="fa fa-facebook-f"></span></a>
                            <a href="#" class="twitter img-circle"><span class="fa fa-twitter"></span></a>
                            <a href="#" class="google-plus img-circle"><span class="fa fa-google-plus"></span></a>
                        </li>
                    </ul>
                 </div>
            </div>
        </div>
    	<!-- Header Upper -->
    	<div class="header-upper">
        	<div class="auto-container clearfix">
            	<!-- Logo -->
                <div class="logo" align="center">
                    <a href="<?php echo BASE_PATH_ADMIN;?>Seeds/"><img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/logo.jpg" alt="Greenture"></a>
					<br /><h5 >BANKIM PROSAD GHOSH SEEDS PVT LTD</h5>
                 </div>
                 
                 <!--Nav Outer-->
                <div class="nav-outer clearfix">
                    <a href="#" class="theme-btn btn-donate" data-toggle="modal" data-target="#donate-popup">Quick Enquery</a>
                    
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        
                        <div class="navbar-header">
                            <!-- Toggle Button -->    	
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation">
                            
                                <li ><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a></li>
                                <li class="dropdown"><a href="javascript:void();">Company Profile</a>
                                    <ul>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/about/">About Us</a></li>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ResearchAndDevelopment/">R & D</a></li>
                                        <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/ContractSeedProduction/">Contract Seed Production</a></li>
                                    </ul>
                                </li>
                               
                                <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/Products/">Products</a></li>
                                <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/NewsEvents/">News & Events</a></li>
                                <li><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                    
                </div>
                
            </div>
        </div><!-- Header Top End -->
        
    </header><!--End Main Header -->
	  