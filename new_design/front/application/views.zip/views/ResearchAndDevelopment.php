<!--Page Title-->
<section class="page-title" style="background-image:url(<?php echo BASE_PATH_ADMIN;?>theme_files/images/background/page-title-bg.jpg);">
    	<div class="auto-container">
        	<div class="sec-title">
                <h1>Research And Development</h1>
                <div class="bread-crumb"><a href="<?php echo BASE_PATH_ADMIN;?>Seeds/">Home</a> / <a href="#" class="current">Research And Development</a></div>
            </div>
        </div>
    </section>
    
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
        	<div class="row clearfix">
                
                <!--Column-->
                <div class="column image-column col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<figure class="image-box video-box">
                        	<img src="<?php echo BASE_PATH_ADMIN;?>theme_files/images/resource/seed_research.png" alt="">
                        </figure>
                    </article>
                </div>
                
                <!--Column-->
                <div class="column default-text-column with-margin col-md-6 col-sm-12 col-xs-12">
                	<article class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                		<h2>Welcome to <span class="theme_color normal-font">Bankim Seed</span></h2>
                        
                        <div class="text">
                            <p align="justify">Research &amp; Development is a continuous &nbsp;process at Bankim Seeds . In last 100 years of  existence , we have identified many farmer&rsquo;s variety which are further used for  varietal development and breeding activity.</p>
                            
                            <p align="justify">&nbsp;Our team of  technically &amp; qualified staff is continuously engaged in varietal  improvement program . In open pollinated crops , our focus on crops like  Amaranthus ,&nbsp; Yard Long Beans , Cow Pea ,  Egg Plant , Cucumber , Onion and Radishhas ensured us to&nbsp; hold sizable market share which are  performing excellent through out the country under varied agro-climatic  conditions.<br>
                                <br>
                              Our Research Farm is spread over area of 30 acres at Hooghly , West Bengal ,  India.&nbsp; Foundation Seed Productions ,  Breeding activity and Extensive Varietal Evaluation activity is carried out  before commercial release&nbsp; of Open  Pollinated and Hybrid varieties.</p>
                            <p align="justify">&nbsp;</p>

                      </div>
                        
                    </article>
                </div>
                
            </div>
            
            
            
        </div>
    </section>
    
    
    <!--Intro Section-->
    <section class="subscribe-intro">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column col-md-9 col-sm-12 col-xs-12">
                	<h2>Get in Touch</h2>
                    For any product related query please feel free to contact us
                </div>
                <!--Column-->
                <div class="column col-md-3 col-sm-12 col-xs-12">
                	<div class="text-right padd-top-20">
                		<a href="<?php echo BASE_PATH_ADMIN;?>Seeds/contact/" class="theme-btn btn-style-one">Leave Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	